/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;

import java.util.Scanner;

/**
 *
 * @author Nico
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       

        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa tu nombre: ");
        String nombre = scanner.nextLine(); // ← cambio aca
        System.out.println("Hola, " + nombre);

        
//                Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Ingresa el primer numero: ");
//        double num1 = scanner.nextDouble();
//
//        System.out.print("Ingresa el segundo numero: ");
//        double num2 = scanner.nextDouble();
//
//        double resultado = num1 / num2; // División con decimales
//
//        System.out.println("Resultado (double): " + resultado);
        
//               Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Ingresa el primer numero entero: ");
//        int num1 = scanner.nextInt();
//
//        System.out.print("Ingresa el segundo numero entero: ");
//        int num2 = scanner.nextInt();
//
//        int resultado = num1 / num2; // División entera: se pierden los decimales
//
//        System.out.println("Resultado (int): " + resultado);
        
//        String nombre = "Juan Perez";
//        int edad = 30;
//        String direccion = "Calle Falsa 123";
//
//        System.out.println("Nombre: " + nombre + 
//                           "\nEdad: " + edad + " anios" +
//                           "\nDireccion: \"" + direccion + "\"");
    
        
//        Scanner scanner = new Scanner(System.in);
//
//        // Solicitar dos numeros enteros
//        System.out.print("Ingresa el primer numero: ");
//        int numero1 = scanner.nextInt();
//
//        System.out.print("Ingresa el segundo numero: ");
//        int numero2 = scanner.nextInt();
//
//        // Operaciones
//        int suma = numero1 + numero2;
//        int resta = numero1 - numero2;
//        int multiplicacion = numero1 * numero2;
//
//        // Division con validacion para evitar division por cero
//        if (numero2 != 0) {
//            double division = (double) numero1 / numero2;
//            System.out.println("\n--- Resultados ---");
//            System.out.println("Suma: " + suma);
//            System.out.println("Resta: " + resta);
//            System.out.println("Multiplicacion: " + multiplicacion);
//            System.out.println("Division: " + division);
//        } else {
//            System.out.println("\nNo se puede dividir por cero.");
//            System.out.println("Suma: " + suma);
//            System.out.println("Resta: " + resta);
//            System.out.println("Multiplicacion: " + multiplicacion);
//        }
//
//        scanner.close();

    
    
        
//        Scanner input = new Scanner(System.in);
//        String nombre;
//        int edad;
//        
//        System.out.println("Ingresa tu nombre: ");
//        nombre = input.nextLine();
//        
//        System.out.println("Ingresa tu edad: ");
//        edad = input.nextInt();
//        
//        System.out.println("Tu nombre es: "+ nombre+"\n" + "Tu edad es: " + edad );
        
//        String nombre = "Pepe";
//        int edad = 30;
//        double altura = 1.75;
//        boolean estudiante = true;
//
//        System.out.println("Nombre: " + nombre);
//        System.out.println("Edad: " + edad);
//        System.out.println("Altura: " + altura + " m");
//        System.out.println("¿Es estudiante?: " + estudiante);
        
        
//        System.out.println("Hola Java!");
        
        
//        Scanner input = new Scanner(System.in);
//        int anioDeNacimiento, anioActual, edadDelUsuario;
//        
//        anioActual = 2023;
//        
//        System.out.println("Ingrese su año de nacimiento: ");
//        anioDeNacimiento = Integer.parseInt(input.nextLine());
//        
//        edadDelUsuario= anioActual - anioDeNacimiento;
//        
//        System.out.println("Su edad es " + edadDelUsuario + " o " + (edadDelUsuario-1) + "años" );

       
   } 
}
